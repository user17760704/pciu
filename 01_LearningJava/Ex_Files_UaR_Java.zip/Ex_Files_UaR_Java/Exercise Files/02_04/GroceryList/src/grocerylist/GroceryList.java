/*
 * This program demonstrates the use of an array
 */
package grocerylist;

/**
 *
 * @author Peggy Fisher
 */
public class GroceryList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
