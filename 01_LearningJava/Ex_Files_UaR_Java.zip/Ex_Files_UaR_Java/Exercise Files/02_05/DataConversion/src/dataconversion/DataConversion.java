/*
 * This program demonstrates implicit and explicit data conversion
 */
package dataconversion;

/**
 *
 * @author Peggy Fisher
 */
public class DataConversion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
