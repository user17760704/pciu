/*
 * This program is designed to calculate the exterior surface area of a house
 */
package simplecalculation;

/**
 *
 * @author Peggy Fisher
 */
public class SimpleCalculation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
