/*
 * This program uses decision logic to determine shipping costs
 * Shipping rates: 
 * Over $75 free
 * Between $50 and $75 the cost is $5
 * Over $25 but less than $50 is $10
 * Less than $25 is $15
 */
package calculateshipping;

/**
 *
 * @author Peggy Fisher
 */
public class CalculateShipping {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
