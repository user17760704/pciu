/*
 * This program demonstrates the concept of overloading methods
 * we will create several methods with the same name but different 
 * parameters or return types
 */
package overloading;

/**
 *
 * @author Peggy Fisher
 */
public class Overloading {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
